import { css } from 'styled-components';

const TextLarge = css`
  line-height: 29px;
  font-size: 24px;
  font-weight: bold;
`;

export default TextLarge;
